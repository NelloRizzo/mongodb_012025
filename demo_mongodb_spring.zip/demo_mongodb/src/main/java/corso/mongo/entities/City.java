package corso.mongo.entities;

import java.math.BigDecimal;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(setterPrefix = "with")
@Document(collection = "mv_cities")
public class City {
	@Id
	private String id;
	@Field("city_id")
	private int cityId;
	private BigDecimal ha;
	private BigDecimal km2;
	private long people;
	private float density;
	private String region;
	private String area;
	private String city;
	private Province province;
}
