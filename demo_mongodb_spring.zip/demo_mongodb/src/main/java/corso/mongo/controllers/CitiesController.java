package corso.mongo.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import corso.mongo.entities.City;
import corso.mongo.repositories.CitiesRepository;

@RestController
@RequestMapping("/api/cities")
public class CitiesController {

	private final CitiesRepository repo;
	
	public CitiesController(CitiesRepository repo) {
		this.repo = repo;
	}
	
	@GetMapping("{acronym}")
	public List<City> getAllCities(@PathVariable String acronym){
		return repo.findAllByProvinceAcronym(acronym);
	}
}
