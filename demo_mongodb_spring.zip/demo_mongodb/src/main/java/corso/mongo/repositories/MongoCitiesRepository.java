package corso.mongo.repositories;

import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.repository.MongoRepository;

import corso.mongo.entities.City;

@Primary
public interface MongoCitiesRepository extends MongoRepository<City, String>, CitiesRepository {

	List<City> findAllByProvinceAcronym(String acronym);
}
