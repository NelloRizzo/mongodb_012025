package corso.mongo.repositories;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import corso.mongo.entities.City;

public interface CitiesRepository extends CrudRepository<City, String>{

	List<City> findAllByProvinceAcronym(String acronym);

}
