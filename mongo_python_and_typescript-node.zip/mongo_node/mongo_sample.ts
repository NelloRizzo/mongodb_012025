import { MongoClient } from 'mongodb'
import dotenv from 'dotenv'
import express from 'express'
dotenv.config()

const host: string = process.env.LOCAL!
console.log("Connecting to", host)

const app = express()

const client = new MongoClient(host)

const getNames = async () => {
    await client.connect()
    const db = client.db("my_python_db")
    const coll = db.collection("myCollection")
    return await (coll.aggregate([
        {
            '$addFields': {
                'fullName': {
                    '$concat': [
                        '$name', ' ', '$surname'
                    ]
                }
            }
        }
    ]).toArray())
}

app.get('/', async (req, res) => {
    const result = await getNames()
    console.log(result)
    res.send(result)
})

app.listen(8080, () => {
    console.log("Server started...")
})