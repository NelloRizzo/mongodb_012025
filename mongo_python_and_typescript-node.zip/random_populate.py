from datetime import datetime, timedelta
import random
from pymongo import MongoClient
from dotenv import load_dotenv
import os

load_dotenv()
host=os.getenv('LOCAL')
print(f"Connecting to {host}")
client = MongoClient(host)

db = client['my_python_db']

data = [{"name":f"Name {x}", "surname": f"Surname {x}"} for x in range(1, 100)]

db["myCollection"].insert_many(data)

