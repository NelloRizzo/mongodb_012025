from datetime import datetime, timedelta
import random
from pymongo import MongoClient
from dotenv import load_dotenv
import os

load_dotenv()
host=os.getenv('LOCAL')
print(f"Connecting to {host}")
client = MongoClient(host)

db = client['my_python_db']

result = db["myCollection"].aggregate([
    {
        '$addFields': {
            'fullName': {
                '$concat': [
                    '$name', ' ', '$surname'
                ]
            }
        }
    }
])

for r in result:
    print(r["fullName"])