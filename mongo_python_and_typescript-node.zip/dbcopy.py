from pymongo import MongoClient
from dotenv import load_dotenv
import os

load_dotenv()

_old = os.getenv('OLD_CONNECTION')
_new = os.getenv('NEW_CONNECTION')
client_old = MongoClient(_old)
client_new = MongoClient(_new)
print(f"Transfer from {_old} to {_new}")
databases = ['italian_cities']

for database in databases:
    db_old = client_old[database]
    print(f"Database {database}")
    for collection in db_old.list_collection_names():
        print(f"\tCopying {collection}...")
        collection_old = db_old[collection]
        db_new = client_new[database]
        collection_new = db_new[collection]
        for document in collection_old.find():
            collection_new.insert_one(document)
        print("\tDone")
print("Finish")