package corso.mongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiscalCodeMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiscalCodeMongoApplication.class, args);
	}

}
