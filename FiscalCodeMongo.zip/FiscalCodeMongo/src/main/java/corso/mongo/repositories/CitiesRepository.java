package corso.mongo.repositories;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import corso.mongo.entities.City;

public interface CitiesRepository extends MongoRepository<City, Integer> {

	Optional<City> findByNameStartsWith(String name);
}
