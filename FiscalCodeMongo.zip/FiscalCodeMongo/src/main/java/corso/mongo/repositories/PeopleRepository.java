package corso.mongo.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import corso.mongo.entities.PersonalData;

public interface PeopleRepository extends MongoRepository<PersonalData, String> {

}
