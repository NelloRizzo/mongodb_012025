package corso.mongo.controllers.responses;

public class EntityResponse {
	
}
