package corso.mongo.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import corso.mongo.entities.PersonalData;
import corso.mongo.repositories.CitiesRepository;
import corso.mongo.repositories.PeopleRepository;
import corso.mongo.services.FiscalCodeService;
import corso.mongo.services.dto.PersonalDataDto;

@RestController
@RequestMapping("/api/people")
public class PeopleController {

	private static final Logger logger = LoggerFactory.getLogger(PeopleController.class);
	private final PeopleRepository repo;
	private final CitiesRepository cities;
	private final FiscalCodeService service;

	public PeopleController(PeopleRepository repo, CitiesRepository cities, FiscalCodeService service) {
		this.repo = repo;
		this.service = service;
		this.cities = cities;
	}

	@PostMapping
	public ResponseEntity<PersonalDataDto> save(@RequestBody PersonalDataDto data) {
		try {
			data.setFiscalCode(service.calculateFiscalCode(data));
			var entity = PersonalData.builder() //
					.withBirthCity(cities.findByNameStartsWith(data.getBirthCity()).orElse(null)) //
					.withBirthday(data.getBirthday()) //
					.withFirstName(data.getFirstName()) //
					.withFiscalCode(data.getFiscalCode()) //
					.withGender(data.getGender()) //
					.withLastName(data.getLastName()) //
					.build();
			repo.save(entity);
			return ResponseEntity.ok(data);
		} catch (Exception e) {
			logger.error("Exception saving person", e);
			return ResponseEntity.badRequest().build();
		}
	}
}
