package corso.mongo.entities;

public enum Gender {
	MALE, FEMALE
}
