package corso.mongo.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(setterPrefix = "with")
@Document(collection = "cities")
public class City {
	@Id
	private String id;
	private String area;
	@Field("capoluogo")
	private int capital;
	@Field("catastale")
	private String cadastral;
	@Field("cod_area")
	private int areaId;
	@Field("cod_comune")
	private int cityId;
	@Field("cod_provincia")
	private int provinceId;
	@Field("cod_regione")
	private int regionId;
	@Field("denominazione")
	private String name;
	@Field("provincia")
	private String province;
	@Field("regione")
	private String region;
	@Field("sigla")
	private String acronym;
}
