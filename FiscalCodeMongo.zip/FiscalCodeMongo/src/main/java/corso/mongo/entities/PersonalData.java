package corso.mongo.entities;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(setterPrefix = "with")
@Document(collection = "people")
public class PersonalData {
	@Id
	private String id;
	private String firstName;
	private String lastName;
	private LocalDate birthday;
	private Gender gender;
	private City birthCity;
	private String fiscalCode;
}
