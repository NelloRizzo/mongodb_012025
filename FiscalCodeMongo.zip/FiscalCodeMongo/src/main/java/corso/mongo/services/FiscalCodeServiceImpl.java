package corso.mongo.services;

import java.time.LocalDate;
import org.springframework.stereotype.Service;

import corso.mongo.entities.City;
import corso.mongo.entities.Gender;
import corso.mongo.repositories.CitiesRepository;
import corso.mongo.services.dto.PersonalDataDto;

@Service
public class FiscalCodeServiceImpl implements FiscalCodeService {

	private final CitiesRepository repo;

	public FiscalCodeServiceImpl(CitiesRepository repo) {
		this.repo = repo;
	}

	@Override
	public String calculateFiscalCode(PersonalDataDto data) {
		var city = repo.findByNameStartsWith(data.getBirthCity()).orElse(City.builder().withCadastral("X000").build())
				.getCadastral();
		var fc = new StringBuilder() //
				.append(handleLastName(data.getLastName())) //
				.append(handleFirstName(data.getFirstName())) //
				.append(handleBirthday(data.getBirthday(), data.getGender())) //
				.append(city); //

		return fc.append(calcCheckCode(fc)).toString();
	}

	private static class LettersSeparator {
		public final StringBuilder consonants = new StringBuilder();
		public final StringBuilder vowels = new StringBuilder();

		public LettersSeparator(String text) {
			text.chars() //
					.filter(c -> Character.isLetter(c)) //
					.map(c -> Character.toUpperCase(c)) //
					.forEach(c -> {
						if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
							vowels.append((char) c);
						else
							consonants.append((char) c);
					});
		}
	}

	private static char calcCheckCode(StringBuilder fc) {
		int[] odds = { 1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23 };
		int sum = 0;
		for (var i = 0; i < 15; ++i) {
			var c = fc.charAt(i);
			var depl = Character.isDigit(c) ? c - '0' : c - 'A';
			sum += (i % 2 == 0 ? odds[depl] : depl);
		}
		return (char) ('A' + sum % 26);
	}

	private static String handleBirthday(LocalDate birthday, Gender gender) {
		String months = "ABCDEHLMPRST";
		var day = birthday.getDayOfMonth() + (gender == Gender.MALE ? 0 : 40);
		return String.format("%ty%c%02d",birthday, months.charAt(birthday.getMonthValue() - 1), day);
	}

	private static String handleFirstName(String firstName) {
		var cv = new LettersSeparator(firstName);
		if (cv.consonants.length() > 3)
			cv.consonants.delete(1, 2);
		return cv.consonants.append(cv.vowels).append("XXX").substring(0, 3);
	}

	private static String handleLastName(String lastName) {
		var cv = new LettersSeparator(lastName);
		return cv.consonants.append(cv.vowels).append("XXX").substring(0, 3);
	}

}
