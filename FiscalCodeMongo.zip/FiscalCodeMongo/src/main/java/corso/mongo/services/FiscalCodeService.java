package corso.mongo.services;

import corso.mongo.services.dto.PersonalDataDto;

public interface FiscalCodeService {
	public String calculateFiscalCode(PersonalDataDto data);
}
