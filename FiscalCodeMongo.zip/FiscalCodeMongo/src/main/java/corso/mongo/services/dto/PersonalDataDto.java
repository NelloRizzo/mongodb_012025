package corso.mongo.services.dto;

import java.time.LocalDate;

import corso.mongo.entities.Gender;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(setterPrefix = "with")
public class PersonalDataDto {
	private String firstName;
	private String lastName;
	private LocalDate birthday;
	private Gender gender;
	private String birthCity;
	private String fiscalCode;
}
