﻿using MongoDB.Bson.Serialization.Attributes;

namespace MongoWebApp.Models
{
    public class Province
    {
        [BsonElement("_id")]
        public int? Id { get; set; }
        [BsonElement("name")]
        public string? Name { get; set; }
        [BsonElement("acronym")]
        public string? Acronym { get; set; }
        [BsonElement("region_id")]
        public int? RegionId { get; set; }

    }
}
