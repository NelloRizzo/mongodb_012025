﻿using MongoDB.Bson;
using MongoDB.Driver;
using MongoWebApp.Models;

namespace MongoWebApp.DataLayer.MongoDb
{
    public class CityDao : MongoDbDao<City>, ICityDao
    {
        private readonly string dbName = "corso";
        private readonly string collectionName = "italian_cities";
        private readonly IMongoCollection<City> _collection;
        public CityDao(IConfiguration config) : base(config)
        {
            _collection = _client.GetDatabase(dbName)?.GetCollection<City>(collectionName) ?? throw new Exception("Database not found");
        }

        public override Task<City> CreateAsync(City entity)
        {
            throw new NotImplementedException();
        }

        public override Task<City> DeleteAsync(string id)
        {
            throw new NotImplementedException();
        }

        public async Task<IAsyncCursor<City>> GetAllAsync(string acronym, int page = 0, int size = 50)
        => await _collection.Aggregate()
            //.AppendStage<City>(BsonDocument.Parse($"{{ $match: {{ sigla: '{acronym}' }} }}"))
            .Match(c => c.Acronym == acronym)
            .AppendStage<City>(BsonDocument.Parse("{ $sort: { denominazione: 1 } }"))
            //.Sort(new SortDefinitionBuilder<City>().Ascending(c => c.Name))
            // .AppendStage<City>(BsonDocument.Parse($"{{ $skip: {page * size} }}"))
            .Skip(page * size)
            // .AppendStage<City>(BsonDocument.Parse($"{{ $limit: {size} }}"))
            .Limit(size) 
            .ToCursorAsync()
            ;

        public override Task<City> GetAsync(string id)
        {
            throw new NotImplementedException();
        }

        public override Task<City> UpdateAsync(string id, City entity)
        {
            throw new NotImplementedException();
        }
    }
}
