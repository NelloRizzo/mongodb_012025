﻿using MongoDB.Driver;
using MongoWebApp.Models;

namespace MongoWebApp.DataLayer
{
    public interface IProvinceDao : IDao<Province>
    {
        Task<IAsyncCursor<Province>> GetAllAsync();
    }
}
