﻿using MongoDB.Driver;
using MongoWebApp.Models;

namespace MongoWebApp.DataLayer
{
    public interface ICityDao : IDao<City>
    {
        Task<IAsyncCursor<City>> GetAllAsync(string acronym, int page = 0, int size = 50);
    }
}
