﻿namespace MongoWebApp.DataLayer
{
    public interface IDao<T>
    {
        Task<T> CreateAsync(T entity);
        Task<T> UpdateAsync(string id, T entity);
        Task<T> DeleteAsync(string id);
        Task<T> GetAsync(string id);
    }
}
