﻿using MongoDB.Driver;
using MongoWebApp.DataLayer;
using MongoWebApp.Models;

namespace MongoWebApp.BusinessLayer
{
    public class ProvinceService : IProvinceService
    {
        protected readonly IProvinceDao _provinceDao;
        public ProvinceService(IProvinceDao provinceDao) { _provinceDao = provinceDao; }
        public async Task<IList<Province>> GetProvincesAsync()
            => await (await _provinceDao.GetAllAsync()).ToListAsync();
    }
}
